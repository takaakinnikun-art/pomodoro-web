import PomodoroTimer from "./PomodoroTimer.jsx";

export default function App() {
  return <PomodoroTimer />;
}
